<?php
 $db = mysqli_connect('192.182.162.1', 'roots', 'P@55word!23$') or
        die ('Unable to connect. Check your connection parameters.');
        mysqli_select_db($db, 'phpcrud' ) or die(mysqli_error($db));
?>